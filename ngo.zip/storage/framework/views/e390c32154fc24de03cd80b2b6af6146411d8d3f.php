<?php if($errors->any()): ?>
<div class="alert alert-danger alert-dismissible fade show">
        <div class="font-medium text-red-600"></div>

        <ul class="mt-3 list-disc list-inside text-sm text-red-600">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

<?php endif; ?>


<!-- <div class="alert alert-danger alert-dismissible fade show">
    
    <strong>Error!</strong> <?php echo e(Session::get('Failed')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
    </button>
</div> --><?php /**PATH E:\xampp\htdocs\premad\ngo\resources\views/admin/inc/validation_message.blade.php ENDPATH**/ ?>