 
<?php $__env->startSection('content'); ?>

 <div class="content-page">
     <div class="container-fluid add-form-list">
        <div class="row">
            <div class="col-sm-8 offset-2">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title">Add services</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('admin/services/update/'.$service->id)); ?>" method="POST" enctype="multipart/form-data">
                          <?php echo e(csrf_field()); ?>

                            <div class="row">                                
                                <div class="col-md-12">                      
                                    <div class="form-group">
                                        <label>Service Title *</label>
                                        <input type="text" class="form-control" placeholder="Enter Category" name="title" value="<?php echo e($service->title); ?>" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div> 

                                <div class="col-md-12">                      
                                    <div class="form-group">
                                        <label>Service Description *</label>
                                        <input type="text" class="form-control" placeholder="Enter Category" name="description" value="<?php echo e($service->description); ?>" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div> 

                                <div class="col-md-12">                      
                                    <div class="form-group">
                                        <label>Service Image *</label>
                                        <input type="file" class="form-control" placeholder="Enter Category" name="image[]" multiple>


                                        <?php $__currentLoopData = $service_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <img src="<?php echo e(asset('storage/service_images/' . $image->image)); ?>"
                                                    style="height: 100px; width:100px; margin:10px auto 10px;text-align: center;border-radius: 50%;">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>                                 
                               </div>                            
                            <button type="submit" class="btn btn-primary mr-2">Update</button>
                            <button type="reset" class="btn btn-danger">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page end  -->
    </div>
      </div>

      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\premad\ngo\resources\views/admin/services/edit.blade.php ENDPATH**/ ?>