
<?php $__env->startSection('content'); ?>



<div class="content-page">
   <div class="container-fluid add-form-list">
    <div class="row">

        <div class="col-lg-12">
          <div class="d-flex flex-wrap align-items-center justify-content-between mb-4">
            <div>
              <h4 class="mb-3">Add Expense</h4>

          </div>
          <a href="<?php echo e(url('admin/expense/index')); ?>" class="btn btn-primary add-list">Expense List</a>
      </div>
  </div>

  <div class="col-sm-8 offset-2">
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <div class="header-title">
                <h4 class="card-title">Add Expense</h4>
            </div>
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('admin/expenses/store')); ?>" data-toggle="validator" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="row">                                
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Select Category *</label>
                        <select name="category_id" class="selectpicker form-control" data-style="py-0">
                          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                          <option value="<?php echo $value->id; ?>" >
                              <?php echo e($value->category_title); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                  </div>  
                  <div class="col-md-12">                      
                    <div class="form-group">
                        <label>Title *</label>
                        <input type="text" class="form-control" placeholder="Enter Title" name="title" required>
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
                <div class="col-md-12">                      
                    <div class="form-group">
                        <label>Description *</label>
                        <input type="text" class="form-control" placeholder="Enter Description" name="description" required>
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
                <div class="col-md-12">                      
                    <div class="form-group">
                        <label>Payment Mode *</label>
                        <input type="text" class="form-control" placeholder="Enter Payment Mode" name="payment_mode" required>
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
                <div class="col-md-12">                      
                    <div class="form-group">
                        <label>Amount *</label>
                        <input type="text" class="form-control" placeholder="Enter Amount" name="amount" required>
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
                <div class="col-md-12">                      
                    <div class="form-group">
                        <label>Added-By *</label>
                        <input type="text" class="form-control" placeholder="Added By" name="added_by" required>
                        <div class="help-block with-errors"></div>
                    </div>
                </div>
                <div class="col-md-12">                      
                    <div class="form-group">
                        <label>Others *</label>
                        <input type="text" class="form-control" placeholder="Other" name="others" required>
                        <div class="help-block with-errors"></div>
                    </div>
                </div>                                 
            </div>                            
            <button type="submit" class="btn btn-primary mr-2">Add category</button>
            <button type="reset" class="btn btn-danger">Reset</button>
        </form>
    </div>
</div>
</div>
</div>
<!-- Page end  -->
</div>
</div>
<!-- </div> -->
<!-- Wrapper End-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\premad\ngo\resources\views/admin/expenses/create.blade.php ENDPATH**/ ?>