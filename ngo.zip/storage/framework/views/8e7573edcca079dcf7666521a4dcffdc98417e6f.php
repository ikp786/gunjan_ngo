 
<?php $__env->startSection('content'); ?>


    

 <div class="content-page">
     <div class="container-fluid add-form-list">
        <div class="row">
            <div class="col-sm-8 offset-2">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title">Add income</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('admin/incomes/update/'.$income->id)); ?>" data-toggle="validator" method="POST">
                          <?php echo e(csrf_field()); ?>

                          <input type="hidden" name="category_id" value="1">
                            <div class="row">                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Category Title *</label>
                                            <select name="title" class="selectpicker form-control" data-style="py-0">
                                                <option value="">Select Category</option>
                                              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo $value->id; ?>" <?php if($value->id == $income->category_id){
                                                    echo "selected";
                                                } ?> >
                                                <?php echo e($value->category_title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                    </div>
                                </div>
                                <div class="col-md-12">                      
                                    <div class="form-group">
                                        <label>Title *</label>
                                        <input type="text" class="form-control" placeholder="Enter Title" name="title" value="<?php echo e($income->title); ?>" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>  
                                <div class="col-md-12">                      
                                    <div class="form-group">
                                        <label>Description *</label>
                                        <input type="text" class="form-control" placeholder="Enter Description" name="description" value="<?php echo e($income->description); ?>" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-12">                      
                                    <div class="form-group">
                                        <label>Payment Mode *</label>
                                        <input type="text" class="form-control" placeholder="Enter Payment Mode" name="payment_mode" value="<?php echo e($income->payment_mode); ?>" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-12">                      
                                    <div class="form-group">
                                        <label>Amount *</label>
                                        <input type="text" class="form-control" placeholder="Enter Amount" value="<?php echo e($income->amount); ?>" name="amount" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-12">                      
                                    <div class="form-group">
                                        <label>Added-By *</label>
                                        <input type="text" class="form-control" placeholder="Added By" value="<?php echo e($income->added_by); ?>" name="added_by" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-12">                      
                                    <div class="form-group">
                                        <label>Others *</label>
                                        <input type="text" class="form-control" placeholder="Other" value="<?php echo e($income->others); ?>" name="others" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>                                
                               </div>                            
                            <button type="submit" class="btn btn-primary mr-2">Update</button>
                            <button type="reset" class="btn btn-danger">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page end  -->
    </div>
      </div>

      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\premad\ngo\resources\views/admin/incomes/edit.blade.php ENDPATH**/ ?>